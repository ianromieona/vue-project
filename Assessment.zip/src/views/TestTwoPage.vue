<script setup>
import TestTwo from "../components/TestTwo.vue";
</script>

<template>
    <main>
        <TestTwo />
    </main>
</template>
