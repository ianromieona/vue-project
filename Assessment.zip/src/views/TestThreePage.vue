<script setup>
import TestThree from "../components/TestThree.vue";
</script>

<template>
    <main>
        <TestThree />
    </main>
</template>
