<script setup>
import TestOne from "../components/TestOne.vue";
</script>

<template>
    <main>
        <TestOne />
    </main>
</template>
